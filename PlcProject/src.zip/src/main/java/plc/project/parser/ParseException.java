package plc.project.parser;

public final class ParseException extends Exception {

    public ParseException(String message) {
        super(message);
    }

}
