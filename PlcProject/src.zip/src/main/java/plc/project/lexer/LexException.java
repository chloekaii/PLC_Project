package plc.project.lexer;

/**
 * IMPORTANT: DO NOT CHANGE! This file is part of our project's API and should
 * not be modified by your solution.
 */
public final class LexException extends Exception {

    public LexException(String message) {
        super(message);
    }

}
